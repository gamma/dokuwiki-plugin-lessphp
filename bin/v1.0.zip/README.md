LessPHP
=======================

Drop-in replacement for the bundled less.inc.php using http://lessphp.gpeasy.com

It will use a different less engine - still written in php - when rendering CSS and LESS files.
